from sklearn.linear_model import LinearRegression
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
iris = load_iris()

X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=1)

reg = LinearRegression()
reg.fit(X_train, y_train)
pred = reg.predict([[ 6.8 , 3.2,  5.9,  2.3]])
print(pred)
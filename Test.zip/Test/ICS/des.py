from Crypto.Cipher import DES


class DESCipher():
    def __init__(self, key):
        self.key = key

    def encrypt(self, plainText):
        obj = DES.new(self.key, DES.MODE_ECB)
        pad = len(plainText) % 8
        if (pad == 0):
            return obj.encrypt(plainText)
        else:
            plainText += 'X' * pad
            return obj.encrypt(plainText)

    def decrypt(self, encryptedText):
        obj = DES.new(self.key, DES.MODE_ECB)
        return obj.decrypt(encryptedText)


if __name__ == '__main__':
    # key must be 8 bytes long
    des = DESCipher('//23@123')
    encryptedText = des.encrypt('Hello World!')
    print(encryptedText)
    print(des.decrypt(encryptedText))

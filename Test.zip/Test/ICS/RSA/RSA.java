package RSA;


import java.util.Scanner;

public class RSA {
    private static Scanner sc;
    private RSA() {
        sc = new Scanner(System.in);
    }

    // return GCD of a and b
    private double gcd(double a, double b) {
        double temp;
        while (true) {
            temp = a%b;
            if (temp == 0)
                return b;
            a = b;
            b = temp;
        }
    }
    private double calculateN(double p, double q) {
        return p*q;
    }

    private double calculatePhi(double p, double q) {
        return (p-1)*(q-1);
    }

    private double calculateE(double p, double q) {
        double e = 2;
        double phi = calculatePhi(p, q);
        while (e < phi) {
            // e must be co-prime to phi and
            // smaller than phi.
            if (gcd(e, phi)==1)
                break;
            else
                e++;
        }
        return e;
    }

    private double calculateD(double P, double Q) {
        double e = calculateE(P, Q);
        //System.out.println("E : "+ e);
        double phi = calculatePhi(P, Q);
        //System.out.println("phi: "+ phi);
        int k = 2;  // A constant value
        double d = 0;
        double temp = 0;
        while (true) {
            temp = (1 + (k*phi))%e;
            System.out.println("Temp: "+ temp);
            if (temp == 0) {
                d = (1 + (k*phi))/e;
                break;
            }
            else {
                k++;
            }
        }
        return d;
    }


    public static void main(String[] args) {
        RSA rsa = new RSA();
        double P, Q;
        System.out.println("Enter value of P?");
        P = sc.nextDouble();
        System.out.println("Enter value of Q?");
        Q = sc.nextDouble();

        double d = rsa.calculateD(P, Q);
        System.out.println("Value of D is: "+ d);
        double n = rsa.calculateN(P, Q);
        System.out.println(n);
        // Message to be encrypted
        System.out.println("Enter Message to be encrypted?");
        double msg = sc.nextDouble();

        double e = rsa.calculateE(P, Q);

        // Encryption c = (msg ^ e) % n
        double c = Math.pow(msg, e) % n;
        System.out.println("\nEncrypted data: "+ c);

        // Decryption m = (c ^ d) % n
        double m = Math.pow(c, d) % n;
        System.out.println("\nOriginal Message Sent: "+ m);
    }
}

package DiffieHellman;


import java.util.Scanner;

public class Main {
    private static Scanner sc;
    Main() {
        sc = new Scanner(System.in);
    }
    private static long calculateValue(long a, long b, long P){
        if (b == 1) {
            return a;
        }
        return (long) (Math.pow(a, b)%P);
    }

    public static void main(String[] args) {
        Main main = new Main();
        long a, b, P, G;
        System.out.println("Enter value of P?");
        P = sc.nextLong();
        System.out.println("Enter value of G?");
        G = sc.nextLong();
        System.out.println("Enter the private key for Alice?");
        a = sc.nextLong();

        long X = calculateValue(G, a, P);

        System.out.println("Enter the private key for Bob?");
        b = sc.nextLong();

        long Y = calculateValue(G, b, P);

        long ka = calculateValue(Y, a, P);
        long kb = calculateValue(X, b, P);

        System.out.println("Secret key for the Alice is: "+ ka);
        System.out.println("Secret key for the Bob is: "+ kb);
    }
}
